create database movies_db;
use movies_db;
create table movies (
movieid int primary key,
tittle varchar(50),
genres varchar(100));
CREATE TABLE users (
    userId INT PRIMARY KEY,
    age INT,
    gender CHAR(1),
    occupation VARCHAR(50),
    zip_code VARCHAR(10)
);

CREATE TABLE ratings (
    userId INT,
    movieId INT,
    rating INT,
    timestamp BIGINT,
    PRIMARY KEY (userId, movieId),
    FOREIGN KEY (userId) REFERENCES users(userId),
    FOREIGN KEY (movieId) REFERENCES movies(movieId)
);
select m.tittle,avg(r.rating)as avg_rating
from movies m join ratings r on m.movieid=r.movieid
group by m.tittle
order by avg_rating
limit 10;
SELECT m.title, COUNT(*) AS num_ratings
FROM ratings r
JOIN movies m ON r.movieId = m.movieId
GROUP BY m.title
ORDER BY num_ratings DESC
LIMIT 10;
SELECT genres, AVG(r.rating) AS avg_rating
FROM ratings r
JOIN movies m ON r.movieId = m.movieId
GROUP BY genres
ORDER BY avg_rating DESC;
SELECT u.userId, AVG(r.rating) AS avg_rating
FROM ratings r
JOIN users u ON r.userId = u.userId
GROUP BY u.userId
ORDER BY avg_rating DESC
LIMIT 10;
SELECT u.gender, AVG(r.rating) AS avg_rating
FROM ratings r
JOIN users u ON r.userId = u.userId
GROUP BY u.gender;
SELECT 
    CASE
        WHEN u.age < 18 THEN 'Under 18'
        WHEN u.age BETWEEN 18 AND 25 THEN '18-25'
        WHEN u.age BETWEEN 26 AND 35 THEN '26-35'
        WHEN u.age BETWEEN 36 AND 50 THEN '36-50'
        ELSE '50+'
    END AS age_group,
    AVG(r.rating) AS avg_rating
FROM ratings r
JOIN users u ON r.userId = u.userId
GROUP BY age_group
ORDER BY age_group;
SELECT *
FROM (
    SELECT m.title, m.genres, AVG(r.rating) AS avg_rating,
           RANK() OVER (PARTITION BY m.genres ORDER BY AVG(r.rating) DESC) AS genre_rank
    FROM ratings r
    JOIN movies m ON r.movieId = m.movieId
    GROUP BY m.title, m.genres
) AS ranked
WHERE genre_rank = 1;
SELECT m.title, AVG(r.rating) AS avg_rating, COUNT(*) AS num_ratings
FROM ratings r
JOIN movies m ON r.movieId = m.movieId
GROUP BY m.title
HAVING AVG(r.rating) >= 4.5 AND COUNT(*) < 50
ORDER BY avg_rating DESC;
SELECT u.userId, COUNT(*) AS num_ratings
FROM ratings r
JOIN users u ON r.userId = u.userId
GROUP BY u.userId
ORDER BY num_ratings DESC
LIMIT 10;
SELECT strftime('%Y-%m', datetime(timestamp, 'unixepoch')) AS month, COUNT(*) AS ratings_count
FROM ratings
GROUP BY month
ORDER BY month;
